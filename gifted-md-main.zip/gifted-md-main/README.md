
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<h1 align="center"> 𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 𝟓.𝟎.𝟎 </h1>

- Bot is Safe for Heroku so don't ask more questions


<details>
<summary>NOTICE!!! (TAP TO READ)</summary>

- For Panel Deployment You must download the zip from panel sections or from below link else your youtube downloaders wont work on panel.

<a href="https://github.com/mouricedevske/gifted-md/archive/refs/heads/main.zip"><img src="https://img.shields.io/badge/DOWNLOAD%20ZIP-yellow" alt="Panel Zip File" width="150"></a>

- You can add your custom premium/unlimited api key on set.js/.env on app.json(heroku) when deploying to avoid any inconveniences caused by free api key limit.
  
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

  <p align="center">
<a href="https://github.com/mouricedevs"><img title="GITHUB" src="https://img.shields.io/badge/GITHUB-GIFTED TECH-red.svg?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/mouricedevs?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/mouricedevs?label=Followers&style=social"></a>
<a href="https://github.com/mouricedevske/gifted-md/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/mouricedevske/gifted-md?&style=social"></a>
<a href="https://github.com/mouricedevske/gifted-md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/mouricedevske/gifted-md?style=social"></a>
<a href="https://github.com/mouricedevske/gifted-md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/mouricedevske/gifted-md?label=Watching&style=social"></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
## 𝟏. 𝐒𝐄𝐓 𝐔𝐏:

**👇FORK REPO(A MUST)**
<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘</summary>
  
- This is essential for you to obtain your own safe forked deployable repo especially heroku users.

<a href="https://github.com/mouricedevske/gifted-md/fork"><img src="https://img.shields.io/badge/CLICK%20HERE-purple" alt="FORK GIFTED-MD" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### 𝟐. 𝐋𝐈𝐍𝐊 𝐖𝐈𝐓𝐇 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏

<details>
<summary>GET YOUR SESSION_ID</summary>
<a href="https://session.giftedtech.my.id"><img src="https://img.shields.io/badge/CLICK%20HERE-green" alt="Pairing Code" width="150"></a>

- Session ID must start with **Gifted~** and is 15 characters in length.
</details>

### 𝟑. 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓 𝐒𝐄𝐂𝐓𝐈𝐎𝐍:
**(A) HEROKU DEPLOYMENT**

<details>
<summary>TAP TO OPEN</summary>
<a href="https://signup.heroku.com/login"><img src="https://img.shields.io/badge/HEROKU%20SIGNUP-white" alt="Pairing Code" width="150"></a>
  
<a href="https://session.giftedtech.my.id/auth"><img src="https://img.shields.io/badge/DEPLOY%20NOW-red" alt="Deploy Gifted" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(B) HOST ON TALKDROVE**
<details>
<summary>TAP TO OPEN</summary>
<a href="https://host.talkdrove.com/auth/signup?ref=53A2DE6D"><img src="https://img.shields.io/badge/TALKDROVE%20SIGNUP-green" alt="TalkDrove" width="150"></a>

<a href="https://youtu.be/YG3-oV2cVj8?feature=shared"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-red" alt="TalkDrove Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(C) RENDER DEPLOYMENT**
<details>
<summary>TAP TO OPEN</summary>
<a href="https://dashboard.render.com/signup"><img src="https://img.shields.io/badge/RENDER%20SIGNUP-green" alt="Render" width="150"></a>

<a href="https://youtu.be/TVu8CQPPliM?feature=shared"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-red" alt="Render Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(D) KOYEB DEPLOYMENT**
<details>
<summary>TAP TO OPEN</summary>
<a href="https://app.koyeb.com/auth/signup"><img src="https://img.shields.io/badge/KOYEB%20SIGNUP-purple" alt="Koyeb" width="150"></a>

<a href="https://app.koyeb.com/services/deploy/?type=git&repository=github.com%2Fmouricedevske%2Fgifted-md&branch=main&name=gifted-md&builder=dockerfile&env%5BAUTO_BLOCK=false%5D=&env%5BSESSION_ID%5D=your%20sessionid%20here&env%5BMODE%5D=private&env=%5BAUTO_READ%5D%3Dfalse&env%5BAUTO_READ_STATUS%5D=true"><img src="https://img.shields.io/badge/DEPLOY%20NOW-black" alt="Koyeb Tutorial" width="150"></a>
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**(E) BOT HOSTING PANEL🔥(DISCORD) DEPLOYMENT**
<details>
<summary>TAP TO OPEN</summary>
<a href="https://github.com/mouricedevske/gifted-md/archive/refs/heads/main.zip"><img src="https://img.shields.io/badge/DOWNLOAD%20FILES-yellow" alt="Rainhost Files" width="150"></a>
  
<a href="https://bot-hosting.net/?aff=1259151615210819614"><img src="https://img.shields.io/badge/SIGNUP%20&%20DEPLOY-gold" alt="Scalingo Deploy" width="150"></a>

<a href="https://youtu.be/1BwOqHhnFGs?feature=shared"><img src="https://img.shields.io/badge/WATCH%20TUTORIAL-red" alt="TalkDrove Tutorial" width="150"></a>
</details

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


### 𝟒. 𝐔𝐏𝐃𝐀𝐓𝐄𝐒 

<details>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘</summary>
  
- **[CONTACT SUPPORT](https://api.giftedtech.my.id/contact) For More Info**
- **Join [WHATSAPP CHANNEL](https://whatsapp.com/channel/0029VaYauR9ISTkHTj4xvi1l) for Daily Updates.**
- **Check out my [Website Profile](https://giftedtech.my.id) for More Projects.**
</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### 𝟓. 𝐑𝐄𝐏𝐎 𝐒𝐓𝐀𝐑 𝐇𝐈𝐒𝐓𝐎𝐑𝐘 

[![Gifted-Md](https://api.star-history.com/svg?repos=mouricedevske/gifted-md&type=Timeline)](#)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
